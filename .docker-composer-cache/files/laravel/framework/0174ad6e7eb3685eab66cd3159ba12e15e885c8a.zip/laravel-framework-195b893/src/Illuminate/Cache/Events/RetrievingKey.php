<?php

namespace Illuminate\Cache\Events;

class RetrievingKey extends CacheEvent
{
    //
}
